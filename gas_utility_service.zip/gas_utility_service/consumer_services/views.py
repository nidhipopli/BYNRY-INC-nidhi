from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import ServiceRequest
from .forms import ServiceRequestForm

def home(request):
    return render(request, 'home.html')

def submit_request(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST, request.FILES)
        if form.is_valid():
            # Save the form data to the database
            service_request = form.save(commit=False)
            service_request.customer = request.user
            service_request.save()
            messages.success(request, 'Your service request has been submitted successfully.')
            return redirect('submit_request')
    else:
        form = ServiceRequestForm()
    return render(request, 'submit_request.html', {'form': form})

def track_request(request, request_id=None):  # Allow request_id to be None
    if request_id:
        service_request = get_object_or_404(ServiceRequest, id=request_id)
    else:
        service_request = None
    return render(request, 'track_request.html', {'service_request': service_request})

def manage_requests(request):
    if not request.user.is_staff:
        return redirect('submit_request')
    service_requests = ServiceRequest.objects.all()
    return render(request, 'manage_requests.html', {'service_requests': service_requests})
