from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # URL pattern for the home page
    path('services/submit/', views.submit_request, name='submit_request'),
    path('submit/', views.submit_request, name='submit_request'),
    path('track/', views.track_request, name='track_request'),

    path('manage/', views.manage_requests, name='manage_requests'),
]
